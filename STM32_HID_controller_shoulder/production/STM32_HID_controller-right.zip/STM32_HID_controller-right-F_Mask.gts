G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,10.0.5*
G04 #@! TF.CreationDate,2026-09-27T23:03:58-07:00*
G04 #@! TF.ProjectId,STM32_HID_controller-right,53544d33-325f-4484-9944-5f636f6e7472,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.5) date 2026-09-27 23:03:58*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10RoundRect,0.250000X0.550000X-0.550000X0.550000X0.550000X-0.550000X0.550000X-0.550000X-0.550000X0*%
%ADD11C,1.600000*%
%ADD12C,2.200000*%
%ADD13O,3.000000X2.500000*%
%ADD14RoundRect,0.250000X-0.600000X-0.725000X0.600000X-0.725000X0.600000X0.725000X-0.600000X0.725000X0*%
%ADD15O,1.700000X1.950000*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,trigger1*
X132000000Y-180000000D03*
D11*
X132000000Y-172380000D03*
G04 #@! TD*
D12*
G04 #@! TO.C,H2*
X123000000Y-133500000D03*
G04 #@! TD*
G04 #@! TO.C,H1*
X142000000Y-133500000D03*
G04 #@! TD*
D13*
G04 #@! TO.C,shoulder1*
X126000000Y-155000000D03*
X138500000Y-155000000D03*
X126000000Y-160000000D03*
X138500000Y-160000000D03*
G04 #@! TD*
D14*
G04 #@! TO.C,J4*
X130000000Y-140000000D03*
D15*
X132500000Y-140000000D03*
X135000000Y-140000000D03*
G04 #@! TD*
M02*
